/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file memory.h
 * @brief Abstraction of memory read and write operations
 *
 * This header file provides an abstraction of reading and
 * writing to memory via function calls. 
 *
 * @author Alex Fosdick
 * @date April 1 2017
 *
 */
#ifndef __MEMORY_H__
#define __MEMORY_H__

#include <stdint.h>
#include <stddef.h>

/**
 * @brief Copies bytes from one memory location into another
 *
 * Given a pointer to a source address to copy data from and a
 * pointer to a destination address to copy data to, this function
 * copies data into the destination pointer in place, taking care
 * to behave properly if the destination and source overlap
 *
 * @param src Pointer to data source
 * @param dest Pointer to data destination
 * @param length Number of bytes to copy
 *
 * @return pointer to destination
 */
uint8_t* my_memmove(uint8_t* src, uint8_t* dest, size_t length);

/**
 * @brief Copies bytes from one memory location into another
 *
 * Given a pointer to a source address to copy data from and a
 * pointer to a destination address to copy data to, this function
 * copies data into the destination pointer in place. If src
 * and dest overlap, behavior is undefined
 *
 * @param src Pointer to data source
 * @param dest Pointer to data destination
 * @param length Number of bytes to copy
 *
 * @return pointer to destination
 */
uint8_t* my_memcopy(uint8_t* src, uint8_t* dest, size_t length);

/**
 * @brief Sets a given value to a memory region
 *
 * Given a memory address, number of bytes, and a value, this function
 * sets the memory to the given value
 *
 * @param addr Pointer to begin of memory region to set
 * @param length Number of bytes to set
 * @param value value to set memory to
 *
 * @return pointer to memory address
 */
uint8_t* my_memset(uint8_t* addr, size_t length, uint8_t value);

/**
 * @brief Zeros out a given memory region
 *
 * Given a memory address and number of bytes, this function zeros
 * out that memory region
 *
 * @param addr Pointer to begin of memory region to set
 * @param length Number of bytes to set
 *
 * @return pointer to memory address
 */
uint8_t* my_memzero(uint8_t* addr, size_t length);

/**
 * @brief Reverses the order of bytes in a given memory region
 *
 * Given a memory address and number of bytes, this function reverses
 * the bytes in that region. e.g. {1, 2, 3, 4} beccomes {4, 3, 2, 1}
 *
 * @param addr Pointer to beginning of memory region to reverse
 * @param length Length of memory region to reverse
 *
 * @return pointer to memory address
 */
uint8_t* my_reverse(uint8_t* addr, size_t length);

/**
 * @brief Allocates a region of 32bit data from dynamic memory
 *
 * Reserves a contiguous region of 32bit words from dynamic memory.
 * If the reservation fails, a NULL pointer is returned
 *
 * @param length Number of words to reserve
 *
 * @return pointer to the reserved memory. If the reservation fails
 *         a null pointer is returned 
 */
int32_t* reserve_words(size_t length);

/**
 * @brief Frees dynamically allocated memory
 *
 * Frees dynamically allocated memory
 *
 * @param addr Pointer to memory address to free
 *
 * @return N/A
 */
void free_words(uint32_t* addr);

/**
 * @brief Sets a value of a data array 
 *
 * Given a pointer to a char data set, this will set a provided
 * index into that data set to the value provided.
 *
 * @param ptr Pointer to data array
 * @param index Index into pointer array to set value
 * @param value value to write the the locaiton
 *
 * @return void.
 */
void set_value(char * ptr, unsigned int index, char value);

/**
 * @brief Clear a value of a data array 
 *
 * Given a pointer to a char data set, this will clear a provided
 * index into that data set to the value zero.
 *
 * @param ptr Pointer to data array
 * @param index Index into pointer array to set value
 *
 * @return void.
 */
void clear_value(char * ptr, unsigned int index);

/**
 * @brief Returns a value of a data array 
 *
 * Given a pointer to a char data set, this will read the provided
 * index into that data set and return the value.
 *
 * @param ptr Pointer to data array
 * @param index Index into pointer array to set value
 *
 * @return Value to be read.
 */
char get_value(char * ptr, unsigned int index);

/**
 * @brief Sets data array elements to a value
 *
 * Given a pointer to a char data set, this will set a number of elements
 * from a provided data array to the given value. The length is determined
 * by the provided size parameter.
 *
 * @param ptr Pointer to data array
 * @param value value to write the the locaiton
 * @param size Number of elements to set to value
 *
 * @return void.
 */
void set_all(char * ptr, char value, unsigned int size);

/**
 * @brief Clears elements in a data array
 *
 * Given a pointer to a char data set, this will set a clear a number
 * of elements given the size provided. Clear means to set to zero. 
 *
 * @param ptr Pointer to data array
 * @param size Number of elements to set to zero
 *
 * @return void.
 */
void clear_all(char * ptr, unsigned int size);

#endif /* __MEMORY_H__ */
