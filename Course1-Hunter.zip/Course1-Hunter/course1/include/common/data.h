/**
 * @file data.h
 * @brief Basic data manipulation methods
 *
 *
 * @author Travis Hunter
 * @date June 6, 2024
 *
 */
#ifndef DATA_H__
#define DATA_H__

#define BASE_16 (16)
#define BASE_10 (10)
#define BASE_8  (8)
#define BASE_2  (2)

#include <stdint.h>

/**
 * @brief Converts data from an integer into ASCII
 *
 * Supports ASCII representation in binary, octal, decimal,
 * and hexadecimal base. Copies the converted string into a passed-in
 * destination pointer, which will be null-terminated.
 * 
 * @param data Integer to convert to ascii
 * @param ptr Address to put string into
 * @param base The base to represent the data in. Supported values
 *             are 2, 8, 10, 16
 *
 * @return The length of the string, including null terminator
 */
uint8_t my_itoa(int32_t data, uint8_t* ptr, uint32_t base);

/**
 * @brief Converts an ascii string to an integer
 *
 * Converts an ascii string to a signed integer.
 * 
 * @param ptr The character string to convert
 * @param digits Number of digits in the character set
 * @param base The base to represent the data in. Supported values
 *             are 2, 8, 10, 16
 *
 * @return The converted 32-bit signed integer
 */
int32_t my_atoi(uint8_t* ptr, uint8_t digits, uint32_t base);


#endif // DATA_H__