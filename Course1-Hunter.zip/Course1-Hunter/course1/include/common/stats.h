/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c
 * @brief Performs some basic statistics on a char array
 *
 * <Add Extended Description Here>
 *
 * @author Travis Hunter
 * @date 1 June, 2024
 *
 */

#ifndef __STATS_H__
#define __STATS_H__

/**
 * @brief Finds the median of a data set
 *
 * Given an a array of unsigned char and a size, this function
 * returns the median value of the passed-in array
 *
 * @param data A pointer to the array of data to find the median of
 * @param size The number of elements in the array
 *
 * @return The median value of the data array
 */
unsigned char find_median(unsigned char* data, unsigned size);

/**
 * @brief Finds the mean of a data set
 *
 * Given an array of unsigned char data and a size, this function
 * finds the mean of the data set.
 *
 * @param data A pointer to the array of data to find the mean of
 * @param size The number of elements in the array
 *
 * @return The mean of the data array
 */
unsigned char find_mean(unsigned char* data, unsigned size);

/**
 * @brief Finds the maximum of a data set
 *
 * Given an array of unsigned char data and a size, this function
 * finds the maximum value in the data set
 *
 * @param data A pointer to the array of data to find the maximum of
 * @param size The number of elements in the array
 *
 * @return The maximum value in the data set
 */
unsigned char find_maximum(unsigned char* data, unsigned size);

/**
 * @brief Finds the minimum of a data set
 *
 * Given an array of unsigned char data and a size, this function
 * finds the minimum falue in the data set
 *
 * @param data A pointer to the array of data to find the minimum of
 * @param size The number of elements in the array
 *
 * @return The minimum value in the data set
 */
unsigned char find_minimum(unsigned char* data, unsigned size);

/**
 * @brief Sorts an array of unsigned chars, from maximum to minimum, in
 *        place
 *
 * This function sorts an array of unsigned data from maximum to minimum.
 * The passed-in array is sorted in place 
 *
 * @param data A pointer to the array of data to sort
 * @param size The number of elements in the array
 *
 * @return None
 */
void sort_array(unsigned char* data, unsigned size);

/**
 * @brief Prints statistics on a data set
 *
 * Prints the maximum, minimum, mean, and median values of an array
 *
 * @param data A pointer to the array of data to print statistics of
 * @param size The number of elements in the array
 *
 * @return None
 */
void print_statistics(unsigned char* data, unsigned size);

/**
 * @brief Prints an array of unsigned chars
 *
 * Prints an array of unsigned chars, 8 values per line
 *
 * @param data A pointer to the array of data to print
 * @param size The number of elements in the array
 *
 * @return None
 */
void print_array(unsigned char* data, unsigned size);

#endif /* __STATS_H__ */
