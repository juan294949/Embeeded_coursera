/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c
 * @brief Performs some basic statistics on a char array
 *
 * <Add Extended Description Here>
 *
 * @author Travis Hunter
 * @date 1 June, 2024
 *
 */

#include "platform.h"
#include "stats.h"

#ifndef NULL
#define NULL 0
#endif

/* quicksort utility function */
void quicksort(unsigned char* data, int start, int end);
unsigned quicksort_partition(unsigned char* data, int start, int end);

void quicksort_reverse(unsigned char* data, int start, int end);
unsigned quicksort_partition_reverse(unsigned char* data, int start, int end);

unsigned char find_median(unsigned char* data, unsigned size) {
  // First sort, then return the middle element
  sort_array(data, size);
  return data[size/2];
}

unsigned char find_mean(unsigned char* data, unsigned size)
{
  if(size == 0 || data == NULL)
  {
    return 0;
  }

  unsigned result = data[0];
  for(unsigned i = 1; i < size; ++i)
  {
    result += data[i];
  }
  result /= size;
  return result;
}

unsigned char find_maximum(unsigned char* data, unsigned size)
{
  if(size == 0 || data == NULL)
  {
    return 0;
  }

  unsigned char result = data[0];
  for(unsigned i = 1; i < size; ++i)
  {
    if(result < data[i])
    {
      result = data[i];
    }
  }
  return result;
}

unsigned char find_minimum(unsigned char* data, unsigned size)
{
  if(size == 0 || data == NULL)
  {
    return 0;
  }

  unsigned char result = data[0];
  for(unsigned i = 1; i < size; ++i)
  {
    if(data[i] < result)
    {
      result = data[i];
    }
  }
  return result;
}

void sort_array(unsigned char* data, unsigned size)
{
  if(size == 0 || data == NULL)
  {
    return;
  }

  // Use quicksort
  quicksort_reverse(data, 0, size-1);
}

void print_array(unsigned char* data, unsigned size)
{
#ifdef VERBOSE
  for(unsigned i = 0; i < size; ++i)
  {
    // Print a new line every eight elements
    if(i % 8 == 0)
    {
      PRINTF("\n");
    }
    PRINTF("%u\t", data[i]);
  }
  PRINTF("\n");

#endif // VERBOSE
}

void print_statistics(unsigned char* data, unsigned size)
{
#ifdef VERBOSE
  PRINTF("****************************\n");
  PRINTF("*        STATISTICS        *\n");
  PRINTF("****************************\n");
  PRINTF("Maximum: %u\n", find_maximum(data, size));
  PRINTF("Minimum: %u\n", find_minimum(data, size));
  PRINTF("Mean:    %u\n", find_mean(data, size));
  PRINTF("Median:  %u\n", find_median(data, size));
  PRINTF("****************************\n");
#endif // VERBOSE
}

/*****************************************************************/
/* Quicksort utility functions.                                  */
/*****************************************************************/

/**
 * The standard quicksort that sorts in ascending order
 */
void quicksort(unsigned char* data, int start, int end)
{
  // End recursion condition
  if(start >= end)
  {
    return;
  }
  unsigned pivotIndex = quicksort_partition(data, start, end);
  quicksort(data, start, pivotIndex-1);
  quicksort(data, pivotIndex+1, end);

}

/**
 * Reverse order quicksort. Sorts in descending order.
 */
void quicksort_reverse(unsigned char* data, int start, int end)
{
  // End recursion condition
  if(start >= end)
  {
    return;
  }
  unsigned pivotIndex = quicksort_partition_reverse(data, start, end);
  quicksort_reverse(data, start, pivotIndex-1);
  quicksort_reverse(data, pivotIndex+1, end);

}

unsigned quicksort_partition(unsigned char* data, int start, int end)
{
  unsigned char pivot = data[end];
  int pIndex = start;

  unsigned char temp = 0; // Temporary value used for swapping

  for(unsigned i = start; i < end; ++i)
  {
    if(data[i] <= pivot)
    {
      temp = data[i];
      data[i] = data[pIndex];
      data[pIndex] = temp;
      pIndex++;
    }
  }
  temp = data[pIndex];
  data[pIndex] = data[end];
  data[end] = temp;

  return pIndex;
}

unsigned quicksort_partition_reverse(unsigned char* data, int start, int end)
{
  unsigned char pivot = data[end];
  int pIndex = start;

  unsigned char temp = 0; // Temporary value used for swapping

  for(unsigned i = start; i < end; ++i)
  {
    if(data[i] >= pivot)
    {
      temp = data[i];
      data[i] = data[pIndex];
      data[pIndex] = temp;
      pIndex++;
    }
  }
  temp = data[pIndex];
  data[pIndex] = data[end];
  data[end] = temp;

  return pIndex;
}
