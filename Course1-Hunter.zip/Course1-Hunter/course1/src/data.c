#include "data.h"
#include "memory.h"

/* converts an int to ASCII using the fact that the
   ASCII character '0' is the number 38, and the characters
   increment from there */
char digit_to_ascii(uint32_t d)
{
    if(d < 10)
    {
    return (char)(d+48);
    }
    else // dealing with a hex number > 10
    {
        return (char)(d+87);
    }
}

uint8_t ascii_to_digit(uint8_t c)
{
    if(c < 60)
    {
    return c-48;
    }
    else // dealing with a hex number a-f
    {
        return c-87;
    }
}

uint8_t my_itoa(int32_t data, uint8_t* ptr, uint32_t base)
{
    uint8_t* origin = ptr;
    int32_t len = 1;
    // If data is zero, just return '0'
    if(data == 0)
    {
        *ptr = digit_to_ascii(0);
        *(ptr + 1) = 0;
        return 2;
    }

    // Deal with BASE 10 first since it's special. The others will use
    // 2s-compliment
    if(base == BASE_10)
    {
        // If it's negative and we're in decimal, prepend a minus sign
        uint8_t is_negative = 0;
        if(data < 0)
        {
            is_negative = 1;
            data = ~data + 1;
            *ptr = '-';
            ptr++;
            len++;
        }
        while(data > 0)
        {
            *ptr = digit_to_ascii(data % 10);
            ptr++;
            len++;
            data /= 10;
        }
        *ptr = 0; // null terminate the string
        /* reverse the string */
        uint8_t first_index = is_negative ? 1 : 0;
        uint8_t last_index = len - 2;
        ptr = origin;
        while(first_index < last_index)
        {
            uint8_t temp = *(ptr + first_index);
            *(ptr + first_index) = *(ptr + last_index);
            *(ptr + last_index) = temp;
            first_index++;
            last_index--;
        }
    } // end of BASE 10 special case
    else
    {
        // The following cases use bitmasking to pick out the correct digits.
        // The last bitwise & takes care of the fact that bitshifting a leading '1'
        // to the right may fill with ones, which we don't want.
        uint32_t mask = 0;
        switch(base)
        {
            case BASE_16:
                mask = 0b1111;
                for(int i = 7; i >= 0; --i)
                {
                    *ptr = digit_to_ascii(((data & (mask << 4*i)) >> 4*i) & mask);
                    ptr++;
                    len++;
                }
                break;
            case BASE_8:
                // octal first character is masked with two bits instead of 3
                *ptr = digit_to_ascii(((data & (0b11 << 30)) >> 30) & 0b11);
                ptr++;
                len++;
                mask = 0b111;
                for(int i = 9; i >= 0; --i)
                {
                    *ptr = digit_to_ascii(((data & (mask << 3*i)) >> 3*i) & mask);
                    ptr++;
                    len++;
                }
                break;
            case BASE_2:
                mask = 0b1;
                for(int i = 31; i >= 0; --i)
                {
                    *ptr = digit_to_ascii(((data & (mask << i)) >> i) & mask);
                    ptr++;
                    len++;
                }
                break;
        }
        *ptr = 0;
    }
    return len;
}

int32_t my_atoi(uint8_t* ptr, uint8_t digits, uint32_t base)
{

    int32_t result = 0;
    uint32_t currentDigit = 1;
    
    int8_t i = digits-2;

    // Account for the fact that base 10 is different and special
    uint8_t is_base10_negative = 0;
    if(ptr[0] == '-')
    {
        is_base10_negative = 1;
        // The first character in the array is '-', which isn't a number
        while(i >= 1)
        {
            uint8_t temp1 = *(ptr + i);
            result += currentDigit * ascii_to_digit(temp1);
            currentDigit *= base;
            --i;
        }
    }
    else
    {
        while(i >= 0)
        {
            uint8_t temp1 = *(ptr + i);
            result += currentDigit * ascii_to_digit(temp1);
            currentDigit *= base;
            --i;
        }
    }

    return (is_base10_negative ? -1 : 1) * result;
}