#include <stdint.h>

// External symbols
extern int main(void);
extern void SystemInit(void);

// Linker script defined symbols
extern uint32_t _etext;
extern uint32_t _data;
extern uint32_t _edata;
extern uint32_t _bss;
extern uint32_t _ebss;
extern uint32_t _estack;

void Reset_Handler(void) {
    uint32_t *pSrc, *pDest;

    // Copy the data segment initializers from flash to SRAM
    pSrc = &_etext;
    for (pDest = &_data; pDest < &_edata;) {
        *pDest++ = *pSrc++;
    }

    // Zero fill the bss segment
    for (pDest = &_bss; pDest < &_ebss;) {
        *pDest++ = 0;
    }

    // Call system initialization function
    SystemInit();

    // Call the application's entry point
    main();
}

// Provide weak aliases for each Exception handler to the Default_Handler.
void Default_Handler(void) __attribute__((weak));
void Default_Handler(void) {
    while (1) {
    }
}
