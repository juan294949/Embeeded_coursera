#include "msp.h"

// System Clock Frequency (Core Clock)
uint32_t SystemCoreClock = 3000000;  // Default system clock frequency

void SystemInit(void) {
    // Set the clocking to run directly from the DCO at 3MHz
    CS->KEY = CS_KEY_VAL;  // Unlock CS module for register access
    CS->CTL0 = 0;          // Reset tuning parameters
    CS->CTL0 = CS_CTL0_DCORSEL_1;  // Set DCO to 3MHz
    CS->CTL1 = CS_CTL1_SELA_2 | CS_CTL1_SELS_3 | CS_CTL1_SELM_3; // Select ACLK = REFO, SMCLK = MCLK = DCO
    CS->KEY = 0;           // Lock CS module from unintended access

    // Update SystemCoreClock variable
    SystemCoreClock = 3000000;
}

void SystemCoreClockUpdate(void) {
    // Function to update the SystemCoreClock variable based on current clock settings
    // This function can be empty if not used in your application
}
