// src/memory.c
#include "memory.h"
#include <stdlib.h>

uint8_t * my_memmove(uint8_t * src, uint8_t * dst, size_t length) {
    if (src < dst && src + length > dst) {
        // Handle overlap by copying from the end
        src += length - 1;
        dst += length - 1;
        while (length--) {
            *dst-- = *src--;
        }
    } else {
        while (length--) {
            *dst++ = *src++;
        }
    }
    return dst;
}

uint8_t * my_memcopy(uint8_t * src, uint8_t * dst, size_t length) {
    while (length--) {
        *dst++ = *src++;
    }
    return dst;
}

uint8_t * my_memset(uint8_t * src, size_t length, uint8_t value) {
    while (length--) {
        *src++ = value;
    }
    return src;
}

uint8_t * my_memzero(uint8_t * src, size_t length) {
    return my_memset(src, length, 0);
}

uint8_t * my_reverse(uint8_t * src, size_t length) {
    uint8_t * start = src;
    uint8_t * end = src + length - 1;
    uint8_t temp;

    while (start < end) {
        temp = *start;
        *start++ = *end;
        *end-- = temp;
    }

    return src;
}

int32_t * reserve_words(size_t length) {
    return (int32_t *) malloc(length * sizeof(int32_t));
}

void free_words(int32_t * src) {
    free(src);
}
