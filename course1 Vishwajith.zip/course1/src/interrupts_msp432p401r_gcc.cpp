#include "msp.h"

// Weak definitions for interrupt handlers
void Reset_Handler(void) __attribute__((weak, alias("Default_Handler")));
void NMI_Handler(void) __attribute__((weak, alias("Default_Handler")));
void HardFault_Handler(void) __attribute__((weak, alias("Default_Handler")));
// Add other handlers as necessary...

void Default_Handler(void) {
    // Infinite loop
    while (1) {
    }
}

// Interrupt vector table
__attribute__((section(".isr_vector")))
void (* const g_pfnVectors[])(void) = {
    // Core Level - CM4
    (void (*)(void))((unsigned long)&__STACK_TOP), // The initial stack pointer
    Reset_Handler,                                // The reset handler
    NMI_Handler,                                  // The NMI handler
    HardFault_Handler,                            // The hard fault handler
    // Add other handlers as necessary...
};

