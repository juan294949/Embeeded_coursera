#include "common/course1.h"

int main() {
#ifdef COURSE1
    course1();
#endif
    return 0;
}

