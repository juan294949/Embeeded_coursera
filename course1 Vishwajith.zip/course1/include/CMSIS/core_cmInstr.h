#ifndef CORE_CMINSTR_H_
#define CORE_CMINSTR_H_

// Include necessary headers or declarations for CORE CM Instr

#endif // CORE_CMINSTR_H_
