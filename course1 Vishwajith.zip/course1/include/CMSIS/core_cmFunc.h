#ifndef CORE_CMFUNC_H_
#define CORE_CMFUNC_H_

// Include necessary headers or declarations for CORE CM Func

#endif // CORE_CMFUNC_H_
