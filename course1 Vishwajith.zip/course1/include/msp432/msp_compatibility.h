#ifndef MSP_COMPATIBILITY_H_
#define MSP_COMPATIBILITY_H_

// Include necessary headers or declarations for MSP compatibility

#endif // MSP_COMPATIBILITY_H_

