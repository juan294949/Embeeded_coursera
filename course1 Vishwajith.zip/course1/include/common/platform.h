#ifndef PLATFORM_H_
#define PLATFORM_H_

#include <stdio.h>

#ifdef VERBOSE
    #define PRINTF(...) printf(__VA_ARGS__)
#else
    #define PRINTF(...)
#endif

#endif // PLATFORM_H_

