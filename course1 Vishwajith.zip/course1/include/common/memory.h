// include/memory.h
#ifndef __MEMORY_H__
#define __MEMORY_H__

#include <stddef.h>
#include <stdint.h>

/**
 * @brief Moves a block of memory from source to destination, handling overlap
 *
 * @param src Pointer to the source memory block
 * @param dst Pointer to the destination memory block
 * @param length Number of bytes to move
 *
 * @return Pointer to the destination memory block
 */
uint8_t * my_memmove(uint8_t * src, uint8_t * dst, size_t length);

/**
 * @brief Copies a block of memory from source to destination
 *
 * @param src Pointer to the source memory block
 * @param dst Pointer to the destination memory block
 * @param length Number of bytes to copy
 *
 * @return Pointer to the destination memory block
 */
uint8_t * my_memcopy(uint8_t * src, uint8_t * dst, size_t length);

/**
 * @brief Sets a block of memory to a specified value
 *
 * @param src Pointer to the source memory block
 * @param length Number of bytes to set
 * @param value Value to set each byte to
 *
 * @return Pointer to the source memory block
 */
uint8_t * my_memset(uint8_t * src, size_t length, uint8_t value);

/**
 * @brief Zeros out a block of memory
 *
 * @param src Pointer to the source memory block
 * @param length Number of bytes to zero out
 *
 * @return Pointer to the source memory block
 */
uint8_t * my_memzero(uint8_t * src, size_t length);

/**
 * @brief Reverses a block of memory
 *
 * @param src Pointer to the source memory block
 * @param length Number of bytes to reverse
 *
 * @return Pointer to the source memory block
 */
uint8_t * my_reverse(uint8_t * src, size_t length);

/**
 * @brief Allocates a block of memory
 *
 * @param length Number of words to allocate
 *
 * @return Pointer to the allocated memory block, or NULL if allocation fails
 */
int32_t * reserve_words(size_t length);

/**
 * @brief Frees a dynamically allocated block of memory
 *
 * @param src Pointer to the memory block to free
 */
void free_words(int32_t * src);

#endif /* __MEMORY_H__ */
