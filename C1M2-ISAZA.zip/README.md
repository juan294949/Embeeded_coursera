# Embeeded_coursera
For my intro to Embedded class online on Coursera. 

# Link 
https://www.coursera.org/learn/introduction-embedded-systems/home/week/1