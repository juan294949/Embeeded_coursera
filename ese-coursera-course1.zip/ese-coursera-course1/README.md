###******************************************************************************
# Copyright (C) 2024 Juan Pablo Isaza
#
# Redistribution, modification or use of this software in source or binary
# forms is permitted as long as the files maintain this copyright. 
#
###*****************************************************************************

### This is a free access repository for the Coursera Specialization of Embedded
### Software Essentials to use in conjunction with the course1, the Introductio
### to Embedded Software and Development Environments.

### The repository is organized in multiple folders:
###      demos -> Materials to help you follow along with videos
###      assessments -> Materials used for assessments
