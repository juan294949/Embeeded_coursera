/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c 
 * @brief Introduction to Embedded Systems Software Week1 Assignment
 *
 * Statistical Analysis of sample data array
 *
 * @author Shivan Rajkumar-Maharaj
 * @date May 20th, 2024
 *
 */

#include <stdio.h>
#include <math.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  
  unsigned char sortedArray[SIZE];
  unsigned int ArrSize = SIZE;
  unsigned char test_median, test_mean, test_maximum, test_minimum;

  sort_array(test, sortedArray, ArrSize);
  test_median = find_median(sortedArray, ArrSize);
  test_mean = find_mean(sortedArray, ArrSize);
  test_maximum = find_maximum(sortedArray, ArrSize);
  test_minimum = find_minimum(sortedArray, ArrSize);

  printf("*** Raw Sample Data ***\n");
  print_array(test, ArrSize);
  printf("*** Sorted Sample Data ***\n");
  print_array(sortedArray, ArrSize);
  print_statistics(test_median, test_mean, test_maximum, test_minimum);
}

void print_statistics(unsigned char Median, unsigned char Mean, unsigned char Maximum, unsigned char Minimum) {

  printf("**** Data Sample Statistical Data ****\n");
  printf("Data Sample Median: %d\n", Median);
  printf("Data Sample Mean: %d\n", Mean);
  printf("Data Sample Maximum: %d\n", Maximum);
  printf("Data Sample Minimum: %d\n", Minimum);

}

void print_array(unsigned char DataArray[], unsigned int Size){

  int sum;

  printf("Data Sample: ");
  for (int i=0; i < Size; i++){
    printf("%d, ", DataArray[i]);
  }

  //Tempoary Print of Array Sum
  /* sum=0;
  for (int i=0; i < Size; i++){
    sum += (int)DataArray[i];
  }
  printf(" Checksum: %d", sum); */
  
  printf("\n");

}

void sort_array(unsigned char DataArray[], unsigned char SortedArray[], unsigned int Size){

  unsigned char bubble,temp;

  // Creating copy of data sample for sorting
  for (int x=0; x<Size; x++){
    SortedArray[x]=DataArray[x];
  }
  //print_array(SortedArray, Size);
  for (int j=1; j <= Size; j++){
    bubble = SortedArray[Size-1];
    for (int k=1; k <= Size-j; k++){
      if (bubble < SortedArray[Size-k]){
        //printf("bubble: %d ArrVal: %d  Index: %d\n", bubble, DataArray[Size-k], Size-k);
        temp=bubble;
        bubble = SortedArray[Size-k];
        SortedArray[Size-k]= temp;
      }
    }
    temp = SortedArray[j-1];
    SortedArray[j-1] = bubble;
    SortedArray[Size-1]=temp;
    //print_array(SortedArray, Size);
  }
}

unsigned char find_median(unsigned char SortedData[], unsigned int Size){

  unsigned char Median;

  if (Size % 2 > 0){
    Median = SortedData[(Size + 1) / 2];
  }
  else{
    Median = floor((SortedData[Size / 2] + SortedData[Size/2 + 1]) / 2);
  }

  return Median;
}

unsigned char find_mean(unsigned char SortedData[], unsigned int Size){

  unsigned char Mean;
  int Sum;

  Sum = 0;
  for (int i=0; i<Size; i++){
    Sum += (int)SortedData[i];
  }
  Mean = (unsigned char)floor(Sum / Size);
  return Mean;
}

unsigned char find_maximum(unsigned char SortedData[], unsigned int Size){

  unsigned char Maximum;

  Maximum = SortedData[0];

  return Maximum;

}

unsigned char find_minimum(unsigned char SortedData[], unsigned int Size){

  unsigned char Minimum;

  Minimum = SortedData[Size-1];

  return Minimum;

}

