
Author: Shivan Rajkumar-Maharaj
Project Name: Introduction to Embedded Systems - Week1 Assignment
Project Description: Simple Statistical Analysis Program

