/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h
 * @brief Introduction to Embedded Systems Software Week1 Assignment
 *
 * Statistical Analysis of sample data array
 *
 * @author Shivan Rajkumar-Maharaj
 * @date May 20th, 2024
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/* Add Your Declarations and Function Comments here */ 

/**
 * @brief Print Statistical Data to Screen
 *
 * Prints Maximum, Minimum, Mean and Median values for Data Set
 *
 * @param Maximum Calculated Maximum of sample set
 * @param Minimum Calculated Minimum of sample set
 * @param Mean Calculated Mean of sample set
 * @param Median Calculated Median of sample set
 *
 * @return None
 */

 void print_statistics(unsigned char, unsigned char, unsigned char, unsigned char);

/**
 * @brief Print Data to Screen
 *
 * Prints Array of numbers passed in to the screen 
 * @param Data_Array_ptr Pointer to Array of Unsigned char of Raw Input Data
 * @param Data_Array_size Unsigned Integer stores size of data array
 *
 * @return None
 */

void print_array(unsigned char[], unsigned int);

 /**
 * @brief Find Median Value within passed array of Unsigned Char
 *
 * Calls the Sort function to create a copy of the passed data that's sorted Largest 
 * to smallest, if the array size is odd the middle array position holds the mean if
 * the array size is even the average of the two middle numbers is calculated result
 * is rounded down to the nearest integer
 * 
 * @param Data_Array_ptr Pointer to Array of Unsigned char of Raw Input Data
 * @param Data_Array_size Unsigned Integer stores size of data array
 *
 * @return rounded down integer of the median
 */

unsigned char find_median(unsigned char[], unsigned int);

  /**
 * @brief Find Mean Value of passed array of Unsigned Char values
 *
 * Finds the sum of all numbers in the passed array and divides the result by the
 * size of the array and rounds down to the nearest integer

 * @param Data_Array_ptr Pointer to Array of Unsigned char of sorted Input Data
 * @param Data_Array_size Unsigned Integer stores size of data array
 *
 * @return rounded down integer of the mean of the array
 */

unsigned char find_mean(unsigned char[], unsigned int); 

   /**
 * @brief Find Maximum Value of passed array of Unsigned Char values
 *
 * Calls the Sort function to create a copy of the passed data that's sorted Largest 
 * to smallest, the first element of the array will be returned as the Maximum

 * @param Data_Array_ptr Array of sorted Unsigned char of sorted Input Data
 * @param Data_Array_size Unsigned Integer stores size of data array
 *
 * @return unsigned char value of the maximum member of the Array
 */

unsigned char find_maximum(unsigned char[], unsigned int); 

    /**
 * @brief Find Minimum Value of passed array of Unsigned Char values
 *
 * Calls the Sort function to create a copy of the passed data that's sorted Largest 
 * to smallest, the last element of the array will be returned as the Maximum

 * @param Data_Array_ptr Array of sorted Unsigned char of sorted Input Data
 * @param Data_Array_size Unsigned Integer stores size of data array
 *
 * @return unsigned char value of the minimum member of the Array
 */

unsigned char find_minimum(unsigned char[], unsigned int); 

    /**
 * @brief Sorts a passed array and returns an array sorted larget to smallest
 *
 * Takes a array of unsigned chars byref and creates a sorted version of the array
 * and returns a sorted array by value

 * @param Data_Array_ptr Pointer to Array of Unsigned char of sorted Input Data
 * @param Data_Array_size Unsigned Integer stores size of data array
 *
 * @return Array of unsigned chars sorted largest to smallest
 */

void sort_array(unsigned char[], unsigned char[], unsigned int);

#endif /* __STATS_H__ */
