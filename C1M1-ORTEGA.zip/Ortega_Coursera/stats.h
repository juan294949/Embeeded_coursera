/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h 
 * @brief Header file
 *
 * This header file include declarations and documentation for the seven 
 * function we needs for find of minimum, maximum, mean and median  
 * of an array data.
 *
 * @author Wilson Ortega
 * @date 01-05-2020
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/**
 * @brief Prints the statistics of an array.

 * A function that prints the statistics of 
 * an array including minimum, maximum, mean, and median.
 *
 * @param data A unsigned char pointer to an n-element data array
 * @param size An unsigned integer as the size of the array
 */
void print_statistics(unsigned char * data, unsigned int size);



/**
 * @brief <Add Brief Description of Function Here>
 *
 * Given an array of data and a length, prints the array 
 * to the screen
 *
 * @param data A unsigned char pointer to an n-element data array
 * @param size An unsigned integer as the size of the array
 *
 */
void print_array(unsigned char * data, unsigned int size);



/**
 * @brief Find and return the median value.
 *
 * Given an array of data and a length, returns the median value
 *
 * @param data A unsigned char pointer to an n-element data array
 * @param size An unsigned integer as the size of the array
 *
 * @return An unsigned char result from the function
 */
unsigned char find_median(unsigned char * data, unsigned int size);



/**
 * @brief Find and return the mean value.
 *
 * Given an array of data and a length, returns the mean
 *
 * @param data A unsigned char pointer to an n-element data array
 * @param size An unsigned integer as the size of the array
 *
 * @return An unsigned char result from the function
 */
unsigned char find_mean(unsigned char * data, unsigned int size);




/**
 * @brief Find and return the maximum value
 *
 * Given an array of data and a length, returns the maximum.
 *
 * @param data A unsigned char pointer to an n-element data array
 * @param size An unsigned integer as the size of the array
 *
 * @return An unsigned char result from the function
 */
unsigned char find_maximum(unsigned char * data, unsigned int size);




/**
 * @brief Find and return the minimum value
 *
 * Given an array of data and a length, returns the minimum.
 *
 * @param data A unsigned char pointer to an n-element data array
 * @param size An unsigned integer as the size of the array
 *
 * @return An unsigned char result from the function
 */
unsigned char find_minimum(unsigned char * data, unsigned int size);




/**
 * @brief Sort an array of data
 *
 * Given an array of data and a length, sorts the array from 
 * largest to smallest. 

 * @param data A unsigned char pointer to an n-element data array
 * @param size An unsigned integer as the size of the array
 *
 */
void sort_array(unsigned char * data, unsigned int size);



#endif /* __STATS_H__ */
