#  Week 1: Application Assignment 

Author: Wilson Ortega
Project Details: This is the first task of the course corresponding to week one. 
Contain two files: "stats.h" and "stats.c". 
stats.h: include declarations and documentation for the seven functions.
stats.c: include the algorithm of seven function and the main function. 


# Compilation Guidelines
$ gcc -o stats.out stats.c
$ ./stats.out
