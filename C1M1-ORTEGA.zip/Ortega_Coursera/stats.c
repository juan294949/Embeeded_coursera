/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c
 * @brief File with function main. 
 *
 * This file present the algorithm to find the different statistical values.
 *
 * @author Wilson Ortega
 * @date 01-05-2020
 *
 */

#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

	unsigned char test[SIZE] = {34, 201, 190, 154,   8, 194,   2,   6,
                              114,  88,  45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};
    
	unsigned char *data = NULL;
	int size = SIZE;
	data = &test[0];

	printf("\nPrint the initial array test[%u]\n\n", size);
	print_array(data,size);

	/* Sort array from largest to smallest */
	sort_array(data,size);
	printf("\n\nPrint the sort array test[%u]\n\n", size);
	print_array(data,size);
	printf("\n\n");

	/* Prints the statistics of an array */
	print_statistics(data, size);
}

/*  Function Definitions */
void print_array(unsigned char * data, unsigned int size){
	for(int j=0; j<size; j++){
		printf("test[%u]=%u;\t", (j+1), *(data+j));
	}
	printf("\n");
}

/*  Function Definitions */
void sort_array(unsigned char * data, unsigned int size){
	unsigned char num;
	for(int h=0; h<size-1; h++){
		num = *(data+h);
		for(int i=(1+h); i<size; i++){
			if(num < *(data+i)){
				*(data+h) 	  = *(data+i);
				*(data+i) = num;
				num = *(data+h);
			}
		}
	}
}

/*  Function Definitions */
unsigned char find_minimum(unsigned char * data, unsigned int size){
	unsigned char min = *data;

	for(int i=1; i<size; i++){
		if(min > *(data+i)){
			min = *(data+i);
		}
	}
	return min;
}

/*  Function Definitions */
unsigned char find_maximum(unsigned char * data, unsigned int size){
	unsigned char max = *data;

	for(int i=1; i<size; i++){
		if(max < *(data+i)){
			max = *(data+i);
		}
	}
	return max;
}

/*  Function Definitions */
unsigned char find_mean(unsigned char * data, unsigned int size){
	unsigned char mean;
	float op=0;
	int temp;
	for(int i=0; i<size; i++){
		op = op + (float)*(data+i);
	}
	op = op/(float)size;
	temp = (int)(op * 100);
	mean = (unsigned char)op;
	temp = temp - ((int)mean*100);
	if(temp>49){
		return mean + 1;
	}else{
		return mean;
	}
}

/*  Function Definitions */
unsigned char find_median(unsigned char * data, unsigned int size){
	unsigned char median;
	int num, x;
	num = size%2;
	if(num==0){ 				/* even number */
		x = size/2;
		median = *(data + x - 1) + *(data + x);
		x = (int)median/2;
		median = (unsigned char)x;
		return median;
	}else{						/* odd number */
		x = (size + 1)/2;
		median = *(data + x - 1);
		return median;
	}
}

/*  Function Definitions */
void print_statistics(unsigned char * data, unsigned int size){
	unsigned char min, max, mean, median;
	printf("Statistical values: \n");

	min = find_minimum(data,size);
	max = find_maximum(data,size);
	printf("Minimum = %u \n", min);
	printf("Maximum = %u \n", max);
	
	mean = find_mean(data,size);
	median = find_median(data,size);

	printf("Mean    = %u \n", mean);
	printf("Median  = %u \n\n", median);
}